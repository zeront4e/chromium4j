package io.github.zeront4e.jwmc;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.List;

public class Main {
    private static final Logger LOGGER = LoggerFactory.getLogger(Main.class);

    private static final List<String> SUPPORTED_COMMANDS = List.of("get-windows", "minimize-window",
            "toggle-window-taskbar-icon");

    public static void main(String[] args) {
        if(args.length == 0) {
            LOGGER.error("Usage: java -jar jwmc.jar <command> <command-argument>");

            System.exit(1);
        }

        String command = args[0];

        switch (command) {
            case "get-windows" -> getWindows(args);
            case "minimize-window" -> minimizeWindow(args);
            case "toggle-window-taskbar-icon" -> toggleWindowTaskbarIcon(args);
            case null, default -> {
                LOGGER.error("Unsupported command: {} Supported commands: {}", command,
                        Arrays.toString(SUPPORTED_COMMANDS.toArray()));

                System.exit(1);
            }
        }
    }

    private static void getWindows(String[] args) {
        String partialWindowTitle = args.length == 2 ? args[1] : null;

        try {
            List<WindowManagerWindow> windows;

            if(partialWindowTitle == null) {
                windows = WindowManagerUtil.getWindows();
            }
            else {
                WindowManagerWindow window = WindowManagerUtil.getWindowOrNull(partialWindowTitle);

                if(window == null) {
                    windows = List.of();
                }
                else {
                    windows = List.of(window);
                }
            }

            System.out.println(windowsToWindowsJsonArray(windows));
        }
        catch (Exception exception) {
            LOGGER.error("Failed to get window for partial title: {}", partialWindowTitle, exception);

            System.exit(1);
        }
    }

    private static void minimizeWindow(String[] args) {
        if(args.length != 2) {
            LOGGER.error("Usage: java -jar jwmc.jar minimize-window <window-id-long>");

            System.exit(1);
        }

        String windowIdString = args[1];

        try {
            long windowIdLong = Long.parseLong(windowIdString);

            WindowManagerUtil.minimizeWindow(windowIdLong);
        }
        catch (Exception exception) {
            LOGGER.error("Failed to minimize window for ID: {}", windowIdString, exception);

            System.exit(1);
        }
    }

    private static void toggleWindowTaskbarIcon(String[] args) {
        if(args.length != 3) {
            LOGGER.error("Usage: java -jar jwmc.jar toggle-window-taskbar-icon <window-id-long> <set-visible-boolean>");

            System.exit(1);
        }

        String windowIdString = args[1];
        String setVisibleString = args[2];

        try {
            long windowIdLong = Long.parseLong(windowIdString);
            boolean setVisibleBoolean = Boolean.parseBoolean(setVisibleString);

            WindowManagerUtil.changeTaskbarVisibility(windowIdLong, setVisibleBoolean);
        }
        catch (Exception exception) {
            LOGGER.error("Failed to toggle window taskbar icon for ID: {}", windowIdString, exception);

            System.exit(1);
        }
    }

    private static String windowsToWindowsJsonArray(List<WindowManagerWindow> windows) {
        StringBuilder stringBuilder = new StringBuilder();

        stringBuilder.append("[");

        boolean firstWindow = true;

        for(WindowManagerWindow window : windows) {
            if(firstWindow) {
                firstWindow = false;
            }
            else {
                stringBuilder.append(", ");
            }

            stringBuilder.append(windowToWindowJson(window));
        }

        stringBuilder.append("]");

        return stringBuilder.toString();
    }

    private static String windowToWindowJson(WindowManagerWindow window) {
        String escapedWindowTitle = window.title().replace("\"", "\\\"");

        return "{" +
                "\"id\": " + window.id() + ", " +
                "\"title\": \"" + escapedWindowTitle + "\"" +
                "}";
    }
}
